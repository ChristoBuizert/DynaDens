%% Intialise forcings on time scale
if numel(Traw)<2
    T_td = Traw*ones(size(t));
 %   T_th = Traw*ones(size(t));
else
    dummy = isnan(Traw(:,2));
    Traw(dummy,:)=[];
    T_td = interp1([Traw(:,1); 1E6],[Traw(:,2); Traw(end,2)],-t);
%    T_th = interp1([Traw(:,1); 1E6],[Traw(:,2); Traw(end,2)],-t);
end

if numel(Accraw)<2
    Acc_d = Accraw*ones(size(t));
else
    Acc_d = interp1([Accraw(:,1); 1E6],[Accraw(:,2); Accraw(end,2)],-t);
end

if Dust
    if numel(Caraw)<2
        Ca_d = Caraw*ones(size(t));
        Ca = Ca_d(1)*ones(N,1);
    else
        Ca_d = interp1([Caraw(:,1); 1E6],[Caraw(:,2); Accraw(end,2)],-t);
        Ca = Ca_d(1)*ones(N,1);
    end
    if strcmp(DensModule,'HL_dynamic_dust')
    elseif strcmp(DensModule,'Barnola_dust')
    elseif strcmp(DensModule,'Arnaud_dust')
    elseif strcmp(DensModule,'mixed_dust')
    else
        error(['Dust can not be included in DensModule ',DensModule]);
    end
end

if isnan(rho_0raw)
    rho0_d =  smooth(7.36E-2+1.06E-3*T_td+6.69E-2*Acc_d*0.918+12*4.77E-3,55);
    % Kaspers et al 2004
else
    rho0_d=rho_0raw*ones(size(t));
end
rho_0 = rho0_d(1);

if isnan(H_eddyraw)
   Heddy_d = max(smooth((-30*Acc_d+9),65),0) ;
else
    if numel(H_eddyraw)==1
        Heddy_d=H_eddyraw*ones(size(t));
    else
        Heddy_d= interp1([H_eddyraw(:,1); 1E6],[H_eddyraw(:,2); H_eddyraw(end,2)],-t);
    end
    
end


%% Initialise firn column

rho  = zeros(N,M);

T_z = zeros(N,M);

if strcmp(DensModule,'none')
    rho(:,1) = rho_ice;
else
    rho(:,1) = HL_steady(Acc_d(1),T_td(1),z,dz,rho_0,rho_ice);
end

if Heatflux>0
    [th_cap th_k th_alpha] = Ice_thermal(T_td(1),rho_ice,rho_ice,conductivity);
    zp = sqrt(2*th_alpha*365.25*24*60*60*z_end/mean(Acc_d));
    T_z(:,1) = T_td(1)- zp*sqrt(pi)/2*(Heatflux/1000)/th_k*(erf(z(end:-1:1)/zp)-erf(z_end/zp));
    clear zp
else
    T_z(:,1) = T_td(1);
end

% T_z(:,1)=T_z(:,1)+0.0001*exp(-((z-800)/3).^2); Use for testing advection

Accu_rho_b1 = [0; dz*cumsum(rho(:,1))];
Accu_rho_b2 = [0; dz*cumsum(rho(:,1))];

% strain and velocity due to ice flow in the ice sheet:

velocity = interp1(Velraw(:,1),Velraw(:,2),z);



%% Initialise layer tracking




if rem(x_layers,dt)>0
    error('Not an integer nr of timesteps in x_layers. Layer tracking not possible.');
end

Newlayer = false(1,M);
Newlayer(1:x_layers/dt:end)=true;
Whichlayer = cumsum(Newlayer);
isochrones = t(Newlayer);
Depth_track2 = NaN*zeros(size(isochrones));
Depth_track2(1) = 0;


closed_off = false(size(isochrones));
locked_in = false(size(isochrones));

Delta_age = NaN*zeros(size(isochrones));
gas_age = NaN*zeros(size(isochrones));

lid = NaN*zeros(size(isochrones));
cod = NaN*zeros(size(isochrones));
DCH = NaN*zeros(size(isochrones));

% track lid at high res. 
lid_hr  = NaN*zeros(1,M);
dch_hr  = NaN*zeros(1,M);
DT_hr  = NaN*zeros(3,M);
dgrav_hr = NaN*zeros(1,M);
d15_hr = NaN*zeros(1,M);
d40_hr = NaN*zeros(1,M);
d86_hr = NaN*zeros(1,M);
d136_hr = NaN*zeros(1,M);

% rho_co = NaN*zeros(size(isochrones));
% rho_lid = NaN*zeros(size(isochrones));

t_lid = NaN*zeros(size(isochrones));
t_co = NaN*zeros(size(isochrones));

d_grav = NaN*zeros(size(isochrones));
d_therm_15N = NaN*zeros(size(isochrones));
d_therm_40Ar = NaN*zeros(size(isochrones));
d_therm_86Kr = NaN*zeros(size(isochrones));
d_therm_136Xe = NaN*zeros(size(isochrones));

% isochr_pos = NaN*zeros(length(isochrones),M);
% isochr_pos(1,1) = 0;
% isochr_rho= NaN*zeros(length(isochrones),M);
% isochr_rho(1,1) = rho_0;
% isochr_T= NaN*zeros(length(isochrones),M);
% isochr_T(1,1) = T_td(1);

