% rho = HL_STEADY(Accumulation, Temperature, z, dz, rho_0, rho_ice)
% calculates the steady state Herron-Langway density profile for given
% climatic conditions in units of g/cm^3
% Accumulation is given in m ice equivalent per year.
% Temperature is in Kelvin.
% Values are given along depth vector z, with increments dz.
% rho_0 is the surface density, rho_ice the density of ice in g/cm^3
 
function rho = HL_steady(Acc,T,z,dz,rho_0,rho_ice)

g = 9.82;       % Gravitational constant
R = 8.31447;    % Gas constant

k0 = 11*exp(-10160/(R*T));  % HL rate constant (eq. 6a)
k1 = 575*exp(-21400/(R*T)); % HL rate constant (eq. 6b)     
N = length(z);


rho = zeros(size(z));       % pre-allocation of memory for speed

% find critical depth
z_crit = 1/(k0*rho_ice)*( log(0.55/(rho_ice-0.55)) - log(rho_0/(rho_ice-rho_0)) );
teller_crit = floor(z_crit/dz)+1;


for teller = 1:teller_crit
    Z0 = exp(rho_ice*k0*z(teller) + log(rho_0/(rho_ice-rho_0) ) );
    rho(teller) = rho_ice*Z0/(1+Z0);
end
for teller = (teller_crit+1):N
    Z1 = exp(rho_ice*k1*(z(teller)-z_crit)/sqrt(Acc*rho_ice) + log(0.55/(rho_ice-0.55))      );
    rho(teller) = rho_ice*Z1/(1+Z1);
end
