function [d h m s] = sec2days(time_in)

d = floor(time_in/(24*60*60));
time_in = time_in - 24*60*60*d;
h = floor(time_in/(60*60));
time_in = time_in - 60*60*h;
m = floor(time_in/60);
time_in = time_in - 60*m;
s = round(time_in);