% smoothdiff(f,dx) differentiates f to x with timestep dx.
% df/dx = (0.5/dx)*([f f(N) f(N)]-[f(1) f(1) f]); 

function out = smoothdiff(f,dx)
N = length(f);

if size(f,1) == 1
    out = (0.5/dx)*([f f(N) f(N)]-[f(1) f(1) f]); 
else
    out = (0.5/dx)*([f; f(N); f(N)]-[f(1); f(1); f]);     
end

out(N+2)=[]; out(1)=[];
out(N) = 2*out(N);
out(1) = 2*out(1);