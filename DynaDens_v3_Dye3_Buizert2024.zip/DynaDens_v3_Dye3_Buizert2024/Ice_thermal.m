% Ice_thermal gives the thermal properties of the firn and ice

function [cap, k, alpha] = Ice_thermal(T,rho,rho_ice,method)

rho=1000*rho;
rho_ice = 1000*rho_ice;

if numel(T)<2
    T = T*ones(size(rho));
end

cap = 152.5+7.122*T;

if nargin<4
    warning('Method of thermal conductivity not defined. Check Load_site.m. Schwerdtfeger used.')
    method = 'Schwerdtfeger';
end
    
if strcmp(method,'VanDusen')
    k = 2.1E-2 + 4.2E-4*rho + 2.2E-9*rho.^3;
elseif strcmp(method,'Schwerdtfeger')
    k_ice = 9.828*exp(-5.7E-3.*T);
    k = 2*k_ice.*rho./(3*rho_ice-rho);
elseif strcmp(method,'mean')
    k_ice = 9.828*exp(-5.7E-3.*T);
    k = 0.5*(2*k_ice.*rho./(3*rho_ice-rho))+0.5*(2.1E-2 + 4.2E-4*rho + 2.2E-9*rho.^3); 
elseif strcmp(method,'Calonne2019')
    a = 0.02; rho_trans = 450;
    theta = 1./( 1+exp(-2*a*(rho-rho_trans)));
    ki_ref = 2.1072; ka_ref = 0.024;
    ki = 9.828*exp(-5.7E-3.*T);    
    ka = -7.2239E-7*T.^2 +0.00043685*T -0.041295;
    k = (1-theta).*(ki.*ka/(ki_ref*ka_ref)).*(0.024-1.23E-4*rho + 2.5E-6*rho.^2)+theta.*ki/ki_ref.*(2.107 + 0.003618*(rho-rho_ice));
else 
    warning('Method of thermal conductivity not defined. Check Load_site.m. Schwerdtfeger used.')
    k_ice = 9.828*exp(-5.7E-3.*T);
    k = 2*k_ice.*rho./(3*rho_ice-rho);
end

alpha = k./(rho.*cap);