%% Firn dens
z = ((dz:dz:z_end)-0.5*dz)';    % midpoint of boxes
z_b = (0:dz:z_end)';            % box boundaries

N = length(z);
N_b = length(z_b);              % N_b is also equal to N+1


%% timing issues

t = -t_end:dt:-t_begin;
M = length(t);
