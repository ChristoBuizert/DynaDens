% Trapezoid(functie,dx) itegrates function 'functie' with stepsize dx.
% Integration goes over the entire vector.

function out = Trapezoid(functie,dx)

out = dx*( sum(functie) -0.5*functie(1) -0.5*functie(length(functie))  );