% ----------------------------------------------------------------
%     Dynamic firn densification model written by Christo Buizert
%
%     College of Earth, Ocean, Atmospheric Sciences, OSU
%     buizertc@science.oregonstate.edu
%
%     DYNAMIC FIRN DENSIFICATION WITH HEAT DIFFUSION
%
%     version 3.0           June 2016
%
%     Application to Greenland Dye 3 site
%     For details see:
%     Buizert et al (2024), The Greenland spatial fingerprint of Dansgaard-Oeschger events in observations and models
%
%
% ----------------------------------------------------------------

clear; close all; format compact;

%% --------------------- GENERAL SETTINGS AND FORCINGS

site = 'Dye3';          % Site or predetermined dataset

%% --------------------- FIRN DENSIFICATION SETTINGS

dz = 1;              % resolution along z
z_end = 1000;          % total modeled depth. Use bedrock for low-acc sites, ~1000m for high-acc sites.

dt = 1;                % calculation increments along t (in yr.)
% Rule of thumb: dt <= (dz*rho_0)/(A*rho_ice)

t_end = 37500;          % oldest age
t_begin = 0;            % youngest age

DensModule = 'Barnola'; % 'HL_dynamic', 'Arnaud', 'Barnola' 'HL_steady' 'none'

x_layers = 20;             % Track isochrone down every x years. Can seriously slows things down if too small.
%% --------------------- HEAT DIFFUSION SETTINGS

HeatDiff = true;               % Model heat diffusion?? 1 = on 0 = off

Deformation_heat = true;       % Include heat generated in densification
Heatflux = 0;                 % Heatflux in mW/m^2 GRIP gets 51.5 mW/m^2 ONLY use when z_end is near bedrock

conductivity = 'Calonne2019';   % 'VanDusen', 'Schwerdtfeger', 'Calonne2019', or 'mean'

Dust = false;                   % Include the effects of dust on densification (experimental); Works with HL_dynamic_dust

Flow_strain =  false;            % Include thinning of firn column due to large-scale ice movement. Only use for thin ice caps. Default is false

Vapor_flux = false;             % Include water vapor transport. Default is false

%% ---------------------- INITIALISE

Load_Dye3_data;     % Load all the Dye3 ice core data

SpaceTimeMesh;      

load('Dye3 data\D3_tuningpars_Buizert2024.mat'); % Load the calibration/tuning result

%% ---------------------- RUN THE MODEL

Generate_T_Acc_Dye3;    % Generate the T and Acc profiles
Initialise_firn_fast;   % Initialize firn
Run_DynaDens_TUNE;      % Run the model     
Progress = [];


Plot_curves_dyna;       % Plot the results on ice age scale

