function dD = HL_semiDyn(rho,rho_ice,mean_acc,T,Acc)

g = 9.82;
R = 8.31447;
Acc = Acc*rho_ice;
mean_acc=mean_acc*rho_ice;

zone_1 = (rho < 0.55);
zone_2 = ((rho >=  0.55));

dD_1 = 11*exp(-10160./(R*T)).*Acc*(rho_ice-rho);
dD_2 = 575*exp(-21400./(R*T)).*(mean_acc.^0.5).*(rho_ice-rho);

dD = dD_1.*zone_1+dD_2.*zone_2;
