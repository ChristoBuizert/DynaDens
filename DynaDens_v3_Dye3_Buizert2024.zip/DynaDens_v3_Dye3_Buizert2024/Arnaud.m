function dD = Arnaud(D,AccD_b,T,z,z_b,dz)

% THIS FUNCTION DOESN'T WORK!!

g = 9.82;
R = 8.31447;
rho_ice = 0.918; 

D_1 = 0.00226*T + 0.03;
A = 7.89E3*exp(-60E3/(R*T));

D_1 = 0.57;
l_prime = (D./D_1).^(1/3);  % Fictitious particle radius used for calculations
Z_1 = 4.55; % Value from Arzt is 7.3. Initial coordination number of packing

l_dprime = l_prime + (4*Z_1*(2*l_prime+1).*((l_prime-1).^2) + 15.5*(3*l_prime+1).*((l_prime-1).^3))./( 12*l_prime.*(4*l_prime - 2*Z_1*(l_prime-1) - 15.5*((l_prime-1).^2)) );
    
Z = Z_1 + 15.5*(l_prime-1);   % Increase in particle coordination (Arzt calls it G)
a = max(0,(pi./(3*Z.*(l_prime.^2))).*(3*(l_dprime.^2-1)*Z_1 + (l_dprime.^2).*15.5.*(2*l_dprime-3) + 15.5 ));  % Average contact area of spheres

P = interp1(z_b,AccD_b,z)*rho_ice*1000*1E-6*g;
P_star = 4*pi*P./(a.*Z.*D);

zone_1 = (D < D_1);
zone_2 = ((D >=  D_1)&(D<0.9));
zone_3 = ((D >=  0.9)&(D<0.95));
zone_4 = (D >=  0.95);


dD_1 = 0.9E-3*(P./(D.^2)).*(1-(5/3)*D);
dD_2 = (365.25*24*60*60)*5.3*A*((D_1*D.^2).^(1/3)).*((a/pi).^(0.5)).*((P_star/3).^3);
if sum(zone_2)
    where = find(zone_2,1,'first');
    gamma = dD_2(where)/dD_1(where-1);
    dD_1 = dD_1*gamma;
end
% 
% dD_3 = 0.008*(1-D);
dD = 0.008*(1-D);

% dD = zeros(size(D));
dD(zone_1) = dD_1(zone_1);
dD(zone_2) = dD_2(zone_2);
% dD(zone_3) = dD_3(zone_3);
% dD(zone_4) = dD_3(zone_4);






