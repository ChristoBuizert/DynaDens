function Toscreen(stage,timestamp,teller,M_d,clocktoc);

if stage ==1
%     clc;
    display('-------------- DynaDens model version 3.0 -------------');
    display(' ');
    display(['- Model Run identifier is ', timestamp]);


elseif stage ==2
%     clc;
%     [t_d t_h t_m t_s] = sec2days(clocktoc*(M_d-1)/teller*(1-(teller-1)/(M_d-1)));
%     display('--------------- DynaDens model version 2.0 -------------');
%     display(' ');
%     display(['- Model Run identifier is ', timestamp]);
%     display(' ');
%     display('- Modeling firn densification and heat diffusion ')
%     display(' ');
%     display(['  Progress is ',num2str(100*(teller-1)/(M_d-1)) ,' %.']);
%     display(['  Time remaining is ', num2str(t_h+24*t_d), ' hours, ', num2str(t_m), ' minutes and ', num2str(t_s), ' seconds.']);

elseif stage ==3
%     clc;
%     [t_d t_h t_m t_s] = sec2days(clocktoc);
%     display('--------------- DynaDens model version 2.0 -------------');
%     display(' ');
%     display(['- Model Run identifier is ', timestamp]);
%     display(' ');
%     display('- Modeling firn densification and heat diffusion ')
%     display(' ');
%     display(['  Progress is ',num2str(100*(teller-1)/(M_d-1)) ,' %.']);
%     display(['  Time elapsed is ', num2str(t_h+24*t_d), ' hours, ', num2str(t_m), ' minutes and ', num2str(t_s), ' seconds.']);
%     
    
    
end