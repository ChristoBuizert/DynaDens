function dD = HL_SJ(rho,rho_ice,Accu_rho,T,Acc,GL)

g = 9.82;
R = 8.31447;
f1=1; f2=1;

z_c = find((rho > 0.55 ),1,'first');

dD = zeros(size(rho));

% possibility to use Greenland modified HL by sigfus
if nargin==6
    if GL
        f1=1;
        f2=1;
    end
end


%% ---- Use HL densification for rho < 0.55
dD(1:z_c) =    f1*11*exp(-10160./(R*T((1:z_c)))).*(Acc*rho_ice).*(rho_ice-rho(1:z_c));


%% --- Use the mystical reference to Siggy in HL paper:

sigma = (Accu_rho-Accu_rho(z_c));

dD((z_c+1):end) = ((f2*575*exp(-21400./(R*T((z_c+1):end)))).^2).*sigma((z_c+1):end).*(rho_ice-rho((z_c+1):end))./(log((rho_ice-0.55)./(rho_ice-rho((z_c+1):end))));

% dD = dD_1.*zone_1+dD_2.*zone_2;
dD(z_c+1)=mean(dD(z_c+[-1 1])); 
dD=real(dD);

