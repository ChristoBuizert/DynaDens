%%% Define temperature profile 

% define the actual temp:
Traw = D3_18O(:,[2 4]);
Traw(:,2) = 273.15-20.5+(Traw(:,2)+27.8)/0.38;
Traw(1,1) = -60;

if size(Tune_ages_T,1)>2
    if size(CoTune_ages_T,1)>0
        temp = [CoTune_ages_T];
        temp(:,2) = interp1(Tune_ages_T,Tune_values_T,temp(:,2));
        temp = [temp;[145000 Tune_values_T(1)];[-100 Tune_values_T(end)]];
    else
        temp = [[145000 Tune_values_T(1)];[-100 Tune_values_T(end)]];        
    end
    temp = sortrows([temp;[Tune_ages_T,Tune_values_T]],1);
    if size(NonTune_ages_T,1)>0
        temp = sortrows([temp;[NonTune_ages_T,zeros(size(NonTune_ages_T))]],1);
    end    
else
    % if only 2 parameters were selected, we optimize the Ca/18O-T relation
%     Traw = D3_18O(:,[2 4]);
%     Traw(:,2) = 273.15-20.5+(Traw(:,2)+27.8)/0.35*(1+Tune_values_T(1)/100)+(1+Tune_values_T(2)/10);
%     Traw(1,1) = -60;
    
    temp = [-100 0
        145000 0];
end

temp(isnan(temp(:,2)),:) = [];
% define the actual temp:
f_T = smooth(smooth(interp1(temp(:,1),temp(:,2),Traw(1,1):10:Traw(end,1)),3),3);
Traw(:,2) = Traw(:,2)+interp1(Traw(1,1):10:Traw(end,1),f_T,Traw(:,1));

%% Define Accumulation profile

Accraw = D3_18O(:,[2 4]);
Accraw(:,2) = 0.67+(Accraw(:,2)+27.8)*0.055;
Accraw(1,1) = -60;


if size(Tune_ages_A,1)>2
    if size(CoTune_ages_A,1)>0
        temp = [CoTune_ages_A];
        temp(:,2) = interp1(Tune_ages_A,Tune_values_A,temp(:,2));
        temp = [temp;[145000 Tune_values_A(1)];[-100 Tune_values_A(end)]];
    else
        temp = [[145000 Tune_values_A(1)];[-100 Tune_values_A(end)]];        
    end
    temp = sortrows([temp;[Tune_ages_A,Tune_values_A]],1);
    if size(NonTune_ages_A,1)>0
        temp = sortrows([temp;[NonTune_ages_A,zeros(size(NonTune_ages_A))]],1);
    end
else
    % if only 2 parameters were selected, we optimize the Ca/18O-Acc relation
%     Accraw = D3_18O(:,[2 4]);
%     Accraw(:,2) = 0.6381*(1+Tune_values_A(2)/100)+(Accraw(:,2)+27.8)*0.0584*(1+Tune_values_A(1)/100);
%     Accraw(1,1) = -60; 
    
    temp = [-100 0
        145000 0];
end

temp(isnan(temp(:,2)),:) = [];
% define the actual acc:
f_A = smooth(smooth(interp1(temp(:,1),temp(:,2),Accraw(1,1):10:Accraw(end,1)),3),3);
Accraw(:,2) = Accraw(:,2).*(1+interp1(Accraw(1,1):10:Accraw(end,1),f_A,Accraw(:,1))/100);
Accraw(:,2) = max(Accraw(:,2),0.04);

