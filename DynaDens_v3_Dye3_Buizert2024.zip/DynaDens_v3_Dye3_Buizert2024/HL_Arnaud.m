function dD = HL_Arnaud(rho,rho_ice,Accu_rho,T,Acc,p_atm)

g = 9.82;
R = 8.31447;
% p_atm = 74000;

[dummy,co_est]=min(abs(rho-0.83));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994
[dummy,co_est]=min(abs(rho-rho_co));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994

p_b = p_atm*ones(size(rho));
p_b = max(p_b,p_b.*(rho > rho_co).*(1-rho_co/rho_ice)./(1-rho/rho_ice))-p_atm;
Dp = 1E-6*(1000*Accu_rho*g-p_b); 


rho_1 = 0.56;
rho_2 = rho_ice*0.9;
 

zone_1 = ( rho <  rho_1);
zone_2 = ((rho >= rho_1)&(rho < rho_2));
zone_3 = ( rho >= rho_2);

%% ---- Use HL densification for rho < rho_1

dD_1 =    11*exp(-10160./(R.*T)).*(Acc*rho_ice).*(rho_ice-rho);

%% ---- Use Arnaud/Goujon (2003) for 0.55 < rho < 0.8


D = rho/rho_ice;

A = 7.89E3*exp(-60E3./(R*T));

D_1 = 0.57; %(0.00226*T + 0.03); %0.57;
l_prime = (D./D_1).^(1/3);  % Fictitious particle radius used for calculations
Z_1 = 5.5; % Value from Arzt is 7.3. Initial coordination number of packing
Z_1 = 110.2*D_1^3-148.594*D_1^2+87.6166*D_1-17; % The coordination nr used in Goujon 2003


l_dprime = l_prime + (4*Z_1*(2*l_prime+1).*((l_prime-1).^2) + 15.5*(3*l_prime+1).*((l_prime-1).^3))./( 12*l_prime.*(4*l_prime - 2*Z_1*(l_prime-1) - 15.5*((l_prime-1).^2)) );
Z = Z_1 + 15.5*(l_prime-1);   % Increase in particle coordination (Arzt calls it G)
a = max(0,(pi./(3*Z.*(l_prime.^2))).*(3*(l_dprime.^2-1)*Z_1 + (l_dprime.^2).*15.5.*(2*l_dprime-3) + 15.5 ));  % Average contact area of spheres

P = Dp;
P_star = 4*pi*P./(a.*Z.*D);


dD_2 = rho_ice*(365.25*24*60*60)*5.3*A.*((D_1*D.^2).^(1/3)).*((a/pi).^(0.5)).*((P_star/3).^3);

%% ---- Use HL for rho > 0.8

dD_3 =  575*exp(-21400./(R*T)).*((Acc*rho_ice)^0.5).*(rho_ice-rho);

% sigma = 1000*(Accu_rho-Accu_rho(z_c))*g;
% 
% dD_3 = ((f2*5.75*exp(-21400./(R*T((z_c+1):end)))).^2).*sigma((z_c+1):end).*(rho_ice-rho((z_c+1):end))./(log((rho_ice-0.55)./(rho_ice-rho((z_c+1):end))));
% 

dD = zeros(size(dD_1));
dD(zone_1) = dD_1(zone_1);
dD(zone_2) = dD_2(zone_2);
dD(zone_3) = dD_3(zone_3);
dD=smooth(smooth(dD,3),3);
dD=real(dD);
