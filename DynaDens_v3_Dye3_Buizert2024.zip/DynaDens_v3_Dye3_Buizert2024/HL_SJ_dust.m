function dD = HL_SJ_dust(rho,rho_ice,Accu_rho,T,Acc,dust,a,b)

g = 9.82;
R = 8.31447;

z_c = find((rho > 0.55 ),1,'first');

dD = zeros(size(rho));

if length(dust)==1
    dust = dust*ones(size(rho));
end


%% ---- Use HL densification for rho < 0.55
dD(1:z_c) =    11*exp(-10160./(R*T((1:z_c)))).*(Acc*rho_ice).*(rho_ice-rho(1:z_c));


%% --- Use the mystical reference to Siggy in HL paper:

sigma = (Accu_rho-interp1(rho(5:200),Accu_rho(5:200),0.530));

dD((z_c+1):end) = ((575*exp(-a*21400*(1-b*log(2*dust((z_c+1):end)))./(R*T((z_c+1):end)))).^2).*sigma((z_c+1):end).*(rho_ice-rho((z_c+1):end))./(log((rho_ice-0.54)./(rho_ice-rho((z_c+1):end))));

% dD = dD_1.*zone_1+dD_2.*zone_2;
dD(z_c+1)=mean(dD(z_c+[-1 1])); 
dD=smooth(real(dD),3);

