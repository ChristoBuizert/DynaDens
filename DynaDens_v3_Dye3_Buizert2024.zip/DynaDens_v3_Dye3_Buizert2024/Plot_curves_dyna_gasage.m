
figure
errorbar(Data_Dage(:,1)/1000-Data_Dage(:,2)/1000,Data_Dage(:,2),Data_Dage(:,3),'.k','markersize',10)
hold on
plot(-isochrones/1000-Delta_age/1000,Delta_age,'linewidth',1,'color',[0 0.2 0.95]);

xlabel('Age (ka BP)','fontsize',12)
ylabel('\Delta age (years)')

figure
errorbar(Data_15N(:,1)/1000-interp1(-isochrones,Delta_age,Data_15N(:,1))/1000,Data_15N(:,2),Data_15N(:,3),'.k','markersize',10)
hold on
plot(-isochrones/1000-Delta_age/1000,d_grav+d_therm_15N,'linewidth',1,'color',[0.9 0 0]);

xlabel('Age (ka BP)','fontsize',12)
ylabel(['\delta^{15}N-N_2 (',char(8240),')'],'fontsize',12)

if exist('Data_excess','var')
    figure
    plot(-isochrones/1000,d_therm_15N-d_therm_40Ar/4,'linewidth',1,'color',[0 0.9 0]);
    hold on
    errorbar(Data_excess(:,1)/1000,Data_excess(:,2)-0.012,Data_excess(:,3),'.k')
    xlabel('Age (ka BP)','fontsize',12)
    ylabel(['\delta^{15}N excess (',char(8240),')'],'fontsize',12)
    xlim([20 24])
end
