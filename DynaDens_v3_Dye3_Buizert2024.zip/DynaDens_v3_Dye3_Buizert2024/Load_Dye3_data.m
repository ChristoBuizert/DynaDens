% load site datafiles. 
clockvec = clock;
clockh=num2str(clockvec(4));
if (length(clockh)==1); clockh=['0',clockh]; end
clockm=num2str(clockvec(5));
if (length(clockm)==1); clockm=['0',clockm]; end
timestamp = [site,'_',DensModule,'_',date, '_', clockh,'h',clockm,'m'];
clear clockvec;

Toscreen(1,timestamp);

g = 9.82;       % gravity
R = 8.31447;    % gas constant

p_atm = 74870;   % Atmospheric pressure in Pa
rho_ice = 0.919; % ice density

GL = false; % if true, run adapted HL equations by Sigfus Johnsen. Default is False. Doesn't actually work that well.

Velraw = [0 1;15 1;2040 0]; % this is the Nye thinning function.

rho_diff = 0.016; % difference between the close-off density (calculated using Martinerie 1994) and the lock-in density.

rho_0raw = 0.35;   % surface firn density     
H_eddyraw=5;       % Lock-in depth


load 'Dye3 data'\D3_data_Buizert2024.mat

Data_15N = D3_15N(:,[2 3 4]);
Data_15N(:,3) = 0.01;
Data_Dage = D3_Da(:,[2 3 4]);

