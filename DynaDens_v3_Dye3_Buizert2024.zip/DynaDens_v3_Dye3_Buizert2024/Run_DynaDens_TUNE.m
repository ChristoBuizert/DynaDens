condition = (M-1);

% Trackemall = NaN(sum(Newlayer),M); 
% Trackemall(1,1) = 0;

Enthalpy=50.9E3;

for teller = 2:M
    
    % ------ Firn Densification
    Accu_rho_b1=Accu_rho_b2;
    
    D = rho(:,teller-1);
    
    A = mean(Acc_d([(teller-1) teller]));
    rho_0 = mean(rho0_d([(teller-1) teller]));
    H_eddy = mean(Heddy_d([(teller-1) teller]));
    
    switch DensModule
        case 'HL_dynamic'
            dD =     HL_SJ(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,GL)*dt;
        case 'Arnaud'
            dD = HL_Arnaud(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm)*dt;
        case 'Barnola'
            dD =   Barnola(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm)*dt;
        case 'HL_steady'
            dD = HerronLangway(D,rho_ice,T_td(teller),Acc_d(teller))*dt;
        case 'Spencer'
            dD = Spencer(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm)*dt;
        case 'none'
            dD =zeros(size(D));
        case 'HL_dynamic_dust'
            dD = HL_SJ_dust(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,Ca,dust_sensitivity_a,dust_sensitivity_b)*dt;
        case 'Barnola_dust'
            dD = Barnola_dust(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm,Ca,dust_sensitivity_a,dust_sensitivity_b)*dt;  
        case 'Arnaud_dust'
            dD = HL_Arnaud_dust(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm,Ca,dust_sensitivity_a,dust_sensitivity_b)*dt;
        case 'mixed_dust'
            dD = smooth(smooth(0.5*HL_SJ_dust(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,Ca,dust_sensitivity_a,dust_sensitivity_b)*dt + 0.5* Barnola_dust(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm,Ca,dust_sensitivity_a,dust_sensitivity_b)*dt,7),9);
        case 'Goujon'
            dD = Goujon(D,rho_ice,0.5*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1))),T_z(:,teller-1),A,p_atm,z)*dt;
    end
       
    if Vapor_flux
        s = 1-rho(:,teller-1)/rho_ice;
        rho_co = (1/( 1/(rho_ice) + T_z(180,teller-1)*6.95E-4 - 0.043));
        rho_lid = rho_co-rho_diff;
        sigma_co = sqrt(0.007^2+0.01^2);  %trapping and layering noise
        lambda = 75/rho_co;
        u=lambda*(75/74*rho_co-rho(:,teller-1));
        v=lambda*sigma_co;
        s_closed = s.*(1-CDF(u,0,v)+exp(-u + 0.5*v^2 +log(CDF(u,v^2,v))) );
        s_open = s-s_closed;
        
        [dummy,minpos] = min(abs(rho(:,teller-1)-rho_lid));
        Diff=1.5*5.75E-10*T_z(:,teller-1).^(1.81).*(max(0,2*(s_open-s_open(minpos))));
        P=3.454E12*exp(-Enthalpy./(R*(T_z(:,teller-1))));
        
        F_H2O = -s_open.*Diff.*(Enthalpy./(R*T_z(:,teller-1))-1).*P./(R*(T_z(:,teller-1).^2)).*smoothdiff(T_z(:,teller-1),dz); % flux in mol m^-2 s^-1
        dD_vapor = -1*smoothdiff(18*F_H2O/1E6,dz)*365.25*24*60*60*dt; % change in water content in Mg m^-3 (or g cm^-3)
    else
        dD_vapor = zeros(size(z));
    end
    
    
    if Flow_strain
        dzp = dz*smoothdiff(A*velocity,dz)*dt*rho_ice./D;    % the reduction in dz due to ice flow thinning
    else
        dzp = zeros(size(z));
    end
    
    
    Accu_rho_b1 = Accu_rho_b1 + [0; cumsum(D.*dzp)] + [0; dz*cumsum(dD_vapor)];
    Newboundary = A*rho_ice/rho_0*dt + [0; cumsum((dz+dzp).*D./(D+dD+dD_vapor))];
    Accu_rho_b2 = interp1([0; Newboundary; Newboundary(end)+200  ],[0; A*rho_ice*dt + Accu_rho_b1; Accu_rho_b1(end) + 200*rho_ice  ],z_b);
    rho(:,teller) = diff(Accu_rho_b2)/dz; rho(:,teller) = min(rho(:,teller),rho_ice);
    
        
    % ------ Heat Diffusion
    if HeatDiff
        T = mean(T_td([(teller-1) teller]));
        [th_cap th_k th_alpha] = Ice_thermal(T_z(:,teller-1),rho(:,teller-1),rho_ice,conductivity);                
        dT_lat = dD_vapor*1E6/18*Enthalpy./(1000*rho(:,teller-1).*th_cap); % go back to mol
        if Deformation_heat % Eq 9.33 from Cuffey and Paterson
            %        drho/dz                       * w                           / rho            *P                                                      / heat capacity
            dT_def = smoothdiff(rho(:,teller-1),dz).*rho_ice./rho(:,teller-1).*A./rho(:,teller-1).*9.82.*0.5.*(Accu_rho_b1(2:end)+Accu_rho_b1(1:(end-1)))./(1000*rho(:,teller-1).*th_cap)*dt;
        else
            dT_def = zeros(size(z));
        end
        T_z(:,teller) = CrankNic_heat(z,dz,dt,th_k,th_cap,th_alpha,rho(:,teller-1),rho_ice./rho(:,teller-1)*A.*velocity,[T;T_z(2:end,teller-1)],dz*Heatflux/1000/th_k(end))+dT_def+dT_lat;
       
    else
        T_z(:,teller) = T_td(teller);
    end
    
    % Track layers 
    Depth_track1=Depth_track2;
    Depth_track1(Depth_track1>200) = NaN;
    selecter = ~isnan(Depth_track1);
    
    Depth_track2(selecter) = interp1(z_b,Newboundary,Depth_track1(selecter));
    selecter = (Depth_track2)>0;
    
    
    if Dust
          Dust_age = interp1([4000,Depth_track2(selecter),0],[-1E6,isochrones(selecter),t(teller)],z);
          Ca = interp1([-1E6,t],[Ca_d(1),Ca_d],Dust_age);
    end
    
    % initialise a new layer to track
    if Newlayer(teller)
        Depth_track2(Whichlayer(teller))=0;
    end
%     Trackemall(:,teller) = Depth_track2;
    
    % and calculate output.. the FAST way ;-)
    dummy_co= 1./((1/rho_ice)+6.95E-4*(T_z(:,teller))-4.3E-2);
    wheretolook = (rho(:,teller)-dummy_co)<0.03;
    
    % which layers are closing off?
    z_cod = interp1((rho(wheretolook,teller)-dummy_co(wheretolook)),z(wheretolook),0);
    closers = (Depth_track2>z_cod)&(~closed_off);
    if sum(closers)
        % What fraction of time did the layer spend above z_cod?
        fraction = (z_cod-Depth_track1(closers))./(Depth_track2(closers)-Depth_track1(closers));
        closed_off(closers) = true; % Mark these as closed off
        cod(closers) = Depth_track1(closers)+fraction.*(Depth_track2(closers)-Depth_track1(closers));
    end
    
     % which layers are locking in? 
    z_cod = interp1((rho(wheretolook,teller)-dummy_co(wheretolook)+rho_diff),z(wheretolook),0);
    lid_hr(teller) = z_cod;
    closers = (Depth_track2>z_cod)&(~locked_in); 
    if sum(closers)
        if sum(closers)>1
           warning('Slow down cowboy! dt should be half of x_layers.') 
        end
        fraction = (z_cod-Depth_track1(closers))./(Depth_track2(closers)-Depth_track1(closers));
        locked_in(closers) = true;
        lid(closers) = Depth_track1(closers)+fraction.*(Depth_track2(closers)-Depth_track1(closers));
        DCH(closers) = lid(closers)-H_eddy;
        dummy_lookup = (z>=H_eddy)&(z<(z_cod+dz/2)); % which depth range is the DCH?
        dummy_T = T_z(dummy_lookup,teller);
        dummy_D = (101325/p_atm)*1.82E-2*(mean(dummy_T)^1.81);
        gas_age(closers) = 0.954*(DCH(closers).^2)/dummy_D + 4.03;
        % now recalculate the dummy_T and DCH at the older time:
        dummy_T = interp1(t((teller-floor(40/dt)):teller)',T_z(dummy_lookup,(teller-floor(40/dt)):teller)',t(teller)-mean(gas_age(closers)));
        dummy_DCH = interp1(t((teller-floor(40/dt)):teller),lid_hr((teller-floor(40/dt)):teller),t(teller)-mean(gas_age(closers)))-H_eddy;
        
        Delta_age(closers) = t(teller)-isochrones(closers)-(1-fraction)*dt -gas_age(closers);
        d_grav(closers) = 1E3*(exp(dummy_DCH*1E-3*9.8/(R*mean(dummy_T)))-1);
        d_therm_15N(closers)  = -1E3*(exp(1E-3*(8.656 - 1232/mean(dummy_T))*log(dummy_T(end)/dummy_T(1)) )-1);
        d_therm_40Ar(closers) = -1E3*(exp(1E-3*(26.08 - 3952/mean(dummy_T))*log(dummy_T(end)/dummy_T(1)) )-1);
        d_therm_86Kr(closers) = -1E3*(exp(1E-3*(5.05 - 580/mean(dummy_T))*log(dummy_T(end)/dummy_T(1)) )-1);
        d_therm_136Xe(closers) = -1E3*(exp(1E-3*(11.07 - 2000/mean(dummy_T))*log(dummy_T(end)/dummy_T(1)) )-1);
    end
       
    
    
%     if rem(teller,condition)==1
%         display(['  Progress is ',num2str(100*(teller-1)/(M-1)) ,' %.']);
%     end
end
% clc;
% Toscreen(3,timestamp,teller,M,toc);
clear dummy* condition closers wheretolook Whichlayer Enthalpy selecter
