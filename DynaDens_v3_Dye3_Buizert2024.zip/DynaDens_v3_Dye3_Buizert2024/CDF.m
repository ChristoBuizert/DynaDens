function [out] = CDF(x,mu,sigma)

% find the distribution funcion for the layered trapping.

out = 0.5+0.5*erf((x-mu)/(sqrt(2)*sigma));