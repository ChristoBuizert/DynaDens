function dD = Goujon(rho,rho_ice,Accu_rho,T,Acc,p_atm,z)

g = 9.82;
R = 8.31447;

eps = 0.01; % sneaky bastards included this trick to keep things from blowing up.
            % value in original (?) model is 0.009; this is too small to
            % solve mismatch. Anais says it depends on choice of dz


D = rho/rho_ice;
P = 1000*Accu_rho*g*1E-6;       % apparently the Goujon model is in bar?!

% Set D_0, the transition between stages 1 and 2
D_0 = 0.00226*(T(1)-273.15)+0.647-eps; 
if D_0>0.59
    D_0=0.59;
end

% Set D_c, the transition between stages 2 and 3 
V_c = 6.95E-4*mean(T(z<50))-0.043;
D_c = 1./(V_c*rho_ice+1);

% zone_1 = (D <= (D_0+2*eps));
% zone_2 = ((D > (D_0+2*eps))&(D<D_c));

zone_1b = (D <= 0.7);
zone_2b = ((D > 0.7)&(D<D_c));
zone_3 = (D >= D_c); %&(D<0.95));
% zone_4 = (D >= 0.95);



% -------------------  zone 1 - DENSIFICATION NEIGE-NEVE (ALLEY)

% dD_1 = 1.5*(P./(D.^2)).*(1-(5/3)*D); % still needs to be normalized; see below
dD_1 = 11*exp(-10160./(R.*T)).*(Acc*rho_ice).*(rho_ice-rho);


% ------------------- zone 2 - DENSIFICATION NEVE-GLACE (ARZT)
% - as copied directly from the Goujon model

Z_0 = 110.2*D_0^3-148.594*D_0^2+87.6166*D_0-17;
rprim = (D/D_0).^(1/3);
Z = Z_0 + 15.5.*(rprim-1);

var1 = 4*Z_0*(2*rprim+1).*((rprim-1).^2);
var2 = 15.5*(3*rprim+1).*((rprim-1).^3);
var3 = 12*rprim.*(4*rprim-2*Z_0.*(rprim-1)-15.5*((rprim-1).^2));
rsec = rprim+(var1+var2)./var3;

var4 = 3*(rsec.^2-1).*Z_0 + 15.5*(2*rsec-3).*(rsec.^2)+15.5;
area = max(0,pi*var4./(3*Z.*(rprim.^2)));   % this gives NaN for the dD before D_0

A_0 = 7.89E3*(365.25*24*3600).*exp(-60000./(R*T));
var = 5.3*((D_0*D.^2).^(1/3)).*((area/pi).^(1/2));

P_eff = 4*pi*P./(area.*Z.*D);
dD_2 = rho_ice*A_0.*var.*(P_eff/3).^3;

% Z_0 = 110.2*D_0^3-148.594*D_0^2+87.6166*D_0-17;
% l_prime = (D/D_0).^(1/3);
% Z = Z_0 + 15.5.*(l_prime-1);
% 
% l_dprime = l_prime + (4*Z_0*(2*l_prime+1).*((l_prime-1).^2) + 15.5*(3*l_prime+1).*((l_prime-1).^3))./( 12*l_prime.*(4*l_prime - 2*Z_0*(l_prime-1) - 15.5*((l_prime-1).^2)) );
% Z = Z_0 + 15.5*(l_prime-1);   % Increase in particle coordination (Arzt calls it G)
% area = (pi./(3*Z.*(l_prime.^2))).*(3*(l_dprime.^2-1)*Z_0 + (l_dprime.^2).*15.5.*(2*l_dprime-3) + 15.5 );  % Average contact area of spheres
% 
% A_0 = 7.89E3*(365.25*24*3600).*exp(-60000./(R*T));
% var = 5.3*((D_0*D.^2).^(1/3)).*((area/pi).^(1/2));
% 
% P_eff = 4*pi*P./(area.*Z.*D);
% dD_2 = A_0.*var.*(P_eff/3).^3;

dummy1 = dD_1(zone_1b);  
dummy2 = dD_2(zone_1b);
dD_1b = min(dummy1,dummy2);
if dummy1(end)<dummy2(end)
    error('you just broke the code. Congratulations')
end
 

% ------------------- zone 3 - DENSIFICATION DE LA GLACE

%cylindrical
Pb = 1E-6*p_atm*(D.*(1-D_c)./(D_c*(1-D)));
P_eff = P + 1E-6*p_atm - Pb;    % go from Pa to MPa

% A_0 = 7.89E3*(365.25*24*3600)*exp(-60000./(R*T));
var1 = D.*(1-D)./((1-((1-D).^(1/3))).^3);
dD_3 = rho_ice*2*A_0.*var1.*((2*P_eff/3).^3);

%spherical

%   (pores spheriques, n=1, conversion MPa-1s-1 en bar-1an-1, Pimienta)
A_0 = 1.2E3*(365.25*24*3600)*exp(-60000./(R*T));    % this densification rate has been multiplied by 100 in the Goujon code..
dD_4 = rho_ice*(9/4)*A_0.*(1-D).*P_eff;

dD_5 = max(dD_3,dD_4);  % as used in the Goujon model; the paper suggests differently; doesn't matter much, as we're below the lock-in anyway.


dD = zeros(size(D));
dD(zone_1b) = dD_1b;
dD(zone_2b) = dD_2(zone_2b);
dD(zone_3) = dD_5(zone_3);

% Top 2 m do not densifiy in Goujon model
dD(z<=2.5) = 0;   
% dD = smooth(dD,3);
