% this solves the diffusion equation c_t = alpha*c_xx + beta*c_x + gamma*c 
% using finite-differences in space and Crank-Nicolson time-stepping.  
% t_0 is the initial time, t_end is the final time, N is the number of mesh-points, 
% and M is the number of time steps.

function Tout = CrankNic_heat(z,dz,dt,th_k,th_c,th_alpha,rho,velocity,Tin,Heatflux)

velocity = velocity/(60*60*24*365.25); % in m/s  
alpha =  (dt*60*60*24*365.25/(2*dz^2))*(th_alpha);   
beta  =  (dt*60*60*24*365.25/(4*dz))*(1./(1000*rho.*th_c).*smoothdiff(th_k,dz) -velocity);
gamma = zeros(size(z));

Q = length(alpha);

% define the matrix A which has to be inverted at every time-step.
A = spdiags([[-1*(alpha(2:(Q-1)) - beta(2:(Q-1))) ; -1; 0] [1; 1+2*alpha(2:(Q-1))-gamma(2:(Q-1))  ; 1] [0 ;0; -1*(alpha(2:(Q-1)) + beta(2:(Q-1)))  ]], -1:1, Q, Q);
RHS = zeros(Q,1);

% A*T_{n+1} = B*T_n
% RHS is B*T_n
% with T_n is temp profile at timestep n

RHS(1) = Tin(1) ;       % right hand side of Crank-Nicolson equation
for i= 2:(Q-1)
    RHS(i) = (alpha(i) - beta(i))*Tin(i-1) + (1 - 2*alpha(i) + gamma(i))*Tin(i) + (alpha(i) + beta(i))*Tin(i+1);
end
RHS(Q) = Heatflux; 

Tout = A\RHS; % Matrix inversion!! Go MATLAB!!
Tout(1) = Tin(1);

