function dD = Spencer(rho,rho_ice,Accu_rho,T,Acc,p_atm)

g = 9.82;
R = 8.31447;
Acc = Acc*rho_ice;

[dummy,co_est]=min(abs(rho-0.83));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994
[dummy,co_est]=min(abs(rho-rho_co));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994

p_b = p_atm*ones(size(rho));
p_b = max(p_b,p_b.*(rho > rho_co).*(1-rho_co./rho_ice)./(1-rho/rho_ice))-p_atm;
p_b = min(p_b,1000*Accu_rho*g);

% effective pressure (still needs the Alley 1989 equation....)
Dp = (1000*Accu_rho*g.*(rho_ice./rho));

zone_1 = (rho < 0.55);
zone_2 = (rho >=  0.55)&(rho < rho_co);
zone_3 = (rho >=  rho_co);

C1 = 3.38E9;
C2 = 46.8E3;
C3 = 0.000121;
C4 = -0.689;
C5 = -0.149;

dD1 = C1*exp(-C2./(R*T)).*(1-rho/rho_ice).*((1-((1-rho/rho_ice ).^C3)).^C4).*(Dp.^C5); 

C1 = 9.06E8;
C2 = 41.0E3;
C3 = 0.0856;
C4 = -1.05;
C5 = -0.0202;

dD2 = C1*exp(-C2./(R*T)).*(1-rho/rho_ice).*((1-((1-rho/rho_ice ).^C3)).^C4).*(Dp.^C5); 

C1 = 1.38E7;
C2 = 30.1E3;
C3 = 0.284;
C4 = -0.0734;
C5 = 0.00322;

Dp = (1000*Accu_rho*g.*(rho_ice./rho)-p_b);
dD3 = C1*exp(-C2./(R*T)).*(1-rho/rho_ice).*((1-((1-rho/rho_ice ).^C3)).^C4).*(Dp.^C5); 

dD = rho.*(dD1.*zone_1 + dD2.*zone_2 + dD3.*zone_3)*1E-3;
dD=real(dD);