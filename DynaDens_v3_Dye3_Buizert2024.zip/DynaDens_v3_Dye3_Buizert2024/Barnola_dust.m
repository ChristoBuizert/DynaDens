function dD = Barnola_dust(rho,rho_ice,Accu_rho,T,Acc,p_atm,dust,a,b)

g = 9.82;
R = 8.31447;

if length(dust)==1
    dust = dust*ones(size(rho));
end

dD = zeros(size(rho));

zone1 = ( rho <  0.56);
zone2 = ((rho >= 0.56)&(rho < 0.8));
zone3 = ( rho >= 0.8);

[dummy,co_est]=min(abs(rho-0.83));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994
[dummy,co_est]=min(abs(rho-rho_co));
rho_co = 0.001/(1/(1000*rho_ice)+T(co_est)*(6.95E-7)-4.3E-5); % co density Martinerie 1994

p_b = p_atm*ones(size(rho));
p_b = max(p_b,p_b.*(rho > rho_co).*(1-rho_co/rho_ice)./(1-rho/rho_ice))-p_atm;
p_b = min(p_b,1000*Accu_rho*g);

%% ---- Use HL densification for rho < 0.55
dD(zone1) =    11*exp(-1.02*(1-0.01*log(2*dust(zone1)))*10160./(R.*T(zone1))).*(Acc*rho_ice).*(rho_ice-rho(zone1));

%% ---- Use Barnola (1991) for 0.55 < rho < 0.8
beta = -29.166; 
gamma = 84.422;
delta = -87.425;
epsilon = 30.673;

D = rho/rho_ice;
f = 10.^(beta*(D.^3) + gamma*(D.^2) + delta*D + epsilon);
Dp = 1E-6*(1000*Accu_rho*g-p_b);        % Schwander's formula A4 is in MPa. 

dD(zone2) = (365.25*24*60*60)*25400*exp(-60000*1.005*(1-0.01*log(2*dust(zone2)))./(R.*T(zone2))).*rho(zone2).*f(zone2).*(Dp(zone2).^3);

%% ---- Use Wilkinson 1975 for rho > 0.8

f = (3/16)*(1-D)./((1-((1-D).^(1/3))).^3); 

dD(zone3) = (365.25*24*60*60)*25400*exp(-60000*1.01*(1-0.01*log(2*dust(zone3)))./(R.*T(zone3))).*rho(zone3).*f(zone3).*(Dp(zone3).^3);

% dD = zeros(size(dD_1));
% dD(zone_1) = dD_1(zone_1);
% dD(zone_2) = dD_2(zone_2);
% dD(zone_3) = dD_3(zone_3);
dD=real(dD);
