function [Total Recent Term Glac] = Calc_misfit_dyna(Recent_Dage, Recent_15N, Data_Dage, Data_15N, isochrones, Delta_age, d_grav,d_therm_15N);

where=isnan(Delta_age)|isnan(d_grav);
Delta_age(where)= [];
d_grav(where) = [];
d_therm_15N(where) = [];
isochrones(where) = [];

where = isochrones>-500;
Recent(1) = abs((nanmean(Delta_age(where)) - Recent_Dage(1) )/Recent_Dage(2)); 
Recent(2) = abs((nanmean(d_grav(where))    - Recent_15N(1)  )/Recent_15N(2 )); 

where = Data_Dage(:,1)<18000;
Term(1) = sqrt(nanmean(((interp1(-isochrones,Delta_age,Data_Dage(where,1))-Data_Dage(where,2))./Data_Dage(where,3)).^2));
where = Data_15N(:,1)<18000;
Term(2) = sqrt(nanmean(((interp1(-isochrones,d_grav+d_therm_15N,Data_15N(where,1))-Data_15N(where,2))./Data_15N(where,3)).^2));

where = Data_Dage(:,1)>18000;
Glac(1) = sqrt(nanmean(((interp1(-isochrones,Delta_age,Data_Dage(where,1))-Data_Dage(where,2))./Data_Dage(where,3)).^2));
where = Data_15N(:,1)>18000;
Glac(2) = sqrt(nanmean(((interp1(-isochrones,d_grav+d_therm_15N,Data_15N(where,1))-Data_15N(where,2))./Data_15N(where,3)).^2));

Total = max(nanmean([Recent(1);Term(1);Glac(1)]),nanmean([Recent(2);Term(2);Glac(2)]));